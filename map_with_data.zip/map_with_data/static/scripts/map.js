let map = document.getElementById('map');
let paths = map.children;


function closeSpCards() {
	let cards = document.getElementsByClassName('sp-card');
	for (let card of cards) {
		card.classList.add('d-none')
	}
}

function openSpCard(index) {
	closeSpCards();
	let card = document.getElementById(`sp-card-${index}`);
	let card_body = document.getElementById(`sp-card-${index}-title`);
	
	
	card.classList.remove('d-none');
}


function openAnalyticsCard() {
	let card = document.getElementById('analytics-card');
	card.classList.remove('d-none');
}

function closeAnalyticsCard() {
	let card = document.getElementById('analytics-card');
	card.classList.add('d-none');
}
/*
for (var i = 0; i < paths.length; i++) {
	paths[i].classList.add('area-click');
	(function(j) {
		paths[j].onclick = () => {openSpCard(j)};
	})(i);
}*/